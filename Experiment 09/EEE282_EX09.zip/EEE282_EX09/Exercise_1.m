clear all;
close all;
clc;

for h = [0.125, 0.25, 0.5, 1]
   
    x = 0:h:3;
y = zeros(1,length(x));
y(1)= 1;

for n=2:length(x)
    
    y(n) = y(n-1)+ h.*((x(n-1)-y(n-1))./2);
end
fprintf('for h = %f\n',h)
disp('         x    Euler y')
disp([x'    y'])
fprintf('\n')


y_exact = 3*exp(-x/2) - 2 + x; 

% Plot
 figure
    plot(x,y)
    hold on
    plot(x,y_exact)
    grid on
    legend('Euler','Exact Solution')
    title(['h = ',num2str(h)])
end  