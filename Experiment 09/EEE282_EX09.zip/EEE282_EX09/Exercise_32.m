clear all;
close all;
clc;

R = 20e3;
C = 10e-6;
E = 117;

h = 0.1;           % step size
t = 0:h:3;
Q = zeros(1, length(t));
Q(1) = 0;

% Euler's Method
for n = 2:length(t)
    Q_pred= Q(n-1) + h * (E/R - Q(n-1) / (R*C));
    Q(n) = Q(n-1) + (h/2)*((E/R - Q(n-1)/(R*C)) + (E/R - Q_pred/(R*C)));
end

disp('    t        Improved Euler Q');
disp([t' Q']);

% Exact solution 
Q_exact = C*E*(1 - exp(-t/(R*C)));

% Plot
plot(t, Q)
hold on
plot(t, Q_exact)
grid on
legend('Improved Euler Method', 'Exact Solution')