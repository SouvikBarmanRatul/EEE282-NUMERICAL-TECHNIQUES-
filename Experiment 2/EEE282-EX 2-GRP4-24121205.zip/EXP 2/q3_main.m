clear all;
close all;
clc;
fprintf('Give the lowest range ti in Celsius scale.\n');%Showing this line in command window.
L_R = input('Lower range ti=');%taking the lower from the user.
fprintf('Give the highest range,tf in Celsius scale.\n');%Showing this line in command window.
U_R = input('Upper range tf=');%taking the upper from the user.
A = Cel_and_Faren_temp(L_R,U_R);%Calling the input function.
