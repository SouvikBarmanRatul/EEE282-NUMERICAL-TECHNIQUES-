clear all;
close all;
clc;
A = input('Give a number=\n');%Input value is taken from the user.
y = Factorial_Calc(A);%Function is being called.
fprintf('The factorial of %d is %d',A,y);%Result is being displayed.
