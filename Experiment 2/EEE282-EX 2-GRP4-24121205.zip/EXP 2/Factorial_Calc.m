function F= Factorial_Calc(n)
%The function calculates the factorial using a for loop with input n and output F.
F=1;%Initailzation of value
for i = 1:n %Condition: for loop will continue from 1 to n.
   F = F*i;% Every value of F is being multiplied with the previous value to get the factorial.
end
