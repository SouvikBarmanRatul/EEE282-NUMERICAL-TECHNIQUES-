function Sum_of_Series = Inp(r,n)
Sum_of_Series = 0;%Initializing value
for i = 0 : n
   z=r^i;%Assigning z = r to the power i.
fprintf('%d+ ',z);%Showing the value of each term.
Sum_of_Series = Sum_of_Series + z;%Getting sum of series by adding previous term with r^n.
end
