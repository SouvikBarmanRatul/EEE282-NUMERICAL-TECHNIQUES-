clear all;
close all;
clc;
A = input ('Give a value of r.\n');% Value of Input, r taken from the user.
fprintf('r= %d\n',A);
Num = input('Give a value of n.\n');% Value of Input, n taken from the user.
fprintf('n=%d\n',Num);
B = Inp(A,Num);%Calling the function.
fprintf('\nSum of Geometric series for the given r=%d  and n=%d is %d',A,Num,B);%Showing the output.


