function temp_F = Cel_and_Faren_temp(ti,tf)
fprintf('Celsius\t Farenheit\n');%Showing this line in the command window.
for i= ti:1:tf
 temp_F = (i .* (9./5)) + 32;%Farenheit_temp=(Celsius_temp*(9/5))+32.
   P = [i,  temp_F];% Celsius and Farenheit temperature written as column matrix
 fprintf('%.2f\t %.2f\n',i,temp_F);%Celsius and Farenheit temperature is shown in command window as column matrix.
end
