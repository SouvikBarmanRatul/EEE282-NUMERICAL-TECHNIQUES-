clear all;
close all;
clc;

% Problem:02(a)- Find a best-fit equation to the data trend for linear (1st order)

% Input the variables

x = 0:4:20; % x = Days
y = [67 84 98 125 149 185]; % y = Amount(x106)

% Find out the value of N, m and c which is needed to find a linear equation. Linear equation: y = mx + c 

N = length(x);
m = (N.* sum(x.*y)- sum(x).*sum(y))/ (N.*sum(x.^2)-(sum(x)).^2);
c = mean(y)- m.*mean(x);

%putting a function so that we can measure every point precisely for finding a linear equation

Y_func = @(xf) m.*xf + c;

xr = 0 : 0.01 : 20;
yr = Y_func(xr);

% best fit linear equation figure

figure(1);
plot(xr, yr, 'b');
grid on;
hold on;

fprintf('The best fit linear equation is: y = %.4f * x + %.4f\n', m, c);
% In this figure, we can see a figure which is a straight line. From this prove, we can reach to a conclusion that we are successful to find the best fit linear equation which is y = mx + c

% I know this is a best fit equation but not an exact equation of the providing variables. So, there must be an error. Let's find the error

Y = Y_func(x);
S = sum((Y-y).^2);

fprintf('Error = %.4f\n', S);

% (b) predict the number of bacteria after 40 days for the fitted equations

day = 40; 
bacteria_numbers = Y_func(day);

fprintf('the number of bacteria after 40 days for the fitted equation is: %d', bacteria_numbers);

