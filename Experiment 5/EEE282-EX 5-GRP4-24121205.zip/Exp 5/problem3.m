clear all;
close all;
clc;

x = [0.4 0.8 1.2 1.6 2 2.3];
y = [800 975 1500 1950 2900 3600];

% Question(c)- To fit these data points, which type of equation do you think would be suitable? Find the equation accordingly. 

%Plotting the points

figure(1)
plot(x,y, 'ro', 'linewidth', 2);

%Displaying the name of the axises

xlabel('x');
ylabel('y');
grid on;
hold on;

fprintf('For linear equation:\n\n');
% Find out the value of N, m and c which is needed to find a liner equation. Linear equation: y = mx + c 

N = length(x);
m = (N.* sum(x.*y)- sum(x).*sum(y))/ (N.*sum(x.^2)-(sum(x)).^2);
c = mean(y)- m.*mean(x);

fprintf('The best fit linear equation is: y = %.4f * x + %.4f\n', m, c);

%find out the error of linear equation

Y_func = @(xf) m.*xf + c;
Y = Y_func(x);
Sl = sum((Y-y).^2);

fprintf('The error for the linear equation is: %.4f\n\n\n', Sl);

fprintf('For parabolic equation:\n\n');

% the parabolic equation is: a(x^2) + bx + c = 0. To find the best fit of this equation, let's distribute it in a PA = Q where we have to find out the matrix of A.

P = [length(x) sum(x)    sum(x.^2);
     sum(x)    sum(x.^2) sum(x.^3);
     sum(x.^2) sum(x.^3) sum(x.^4)];
Q = [sum(y) sum(x.*y) sum((x.^2).*y)]';

% Let's find the matrix A

A = P\Q; % A = [Ao A1 A2]

fprintf('The best fit parabolic equation is: %.4f * (x^2) + %.4f * x + %.4f = 0\n', A(3), A(2), A(1));

%Find out the error for the parabolic equation

Z_func= @(xf) A(3).*(xf).^2 + A(2).*xf + A(1);
Z = Z_func(x);
Sp = sum((Z-y).^2);

fprintf('Error = %.4f\n\n\n', Sp);

if Sp>Sl
    fprintf('As Sp>Sl, the error of linear equation is less than parabolic equation. So, The best equation is linear equation.\n\n');
    fprintf('The best fit equation is: y = %.4f * x + %.4f\n', m, c);
    
    xr = 0.4:0.01:2.3;
    yr = Y_func(xr);
    figure(2)
    plot(xr, yr, 'r');
    grid on;
    hold on;
    
else
    fprintf('As Sl>Sp, the error of parabolic equation is less than linear equation. So, The best equation is parabolic equation.\n\n');
    fprintf('The best fit equation is: %.4f * (x^2) + %.4f * x + %.4f = 0\n', A(3), A(2), A(1));
    
    xr = 0.4:0.01:2.3;
    yr = Z_func(xr);
    figure(2)
    plot(xr, yr, 'r');
    xlabel('x');
    ylabel('y');
    grid on;
    hold on;
end

