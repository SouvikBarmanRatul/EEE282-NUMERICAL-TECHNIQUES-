clear all;
close all;
clc;
x = [26.67 93.33 148.69 315.56];  %x = Temperature in Degree Celcius
y = [1.35 0.085 0.012 0.00075];   %y = Viscosity in (N.s/m^2)
%Question(b): After taking the log of the data, use linear regression to find the equation of the line that best fits the data.
%calculating the logarithm of the given value
x1 = log(x);
y1 = log(y);
% Find out the value of N, m and c which is needed to find a liner equation. Linear equation: y = mx + c
N = length(x1);
m = (N.* sum(x1.*y1)- sum(x1).*sum(y1))/ (N.*sum(x1.^2)-(sum(x1)).^2);
c = mean(y1)- m.*mean(x1);
fprintf('The linear equation of the line that best fits the data is: log(y) = %.4f * log(x) + %.4f\n', m, c);
%find out the error
Y_func = @(xf) m.*xf + c;
Y = Y_func(x1);
S = sum((Y-y1).^2);
fprintf('This is the best fit equation but not an exact equation of the providing variables. So, there must be an error. the error is : %.4f\n', S);