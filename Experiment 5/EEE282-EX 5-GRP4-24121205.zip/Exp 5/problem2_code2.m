clear all;
close all;
clc;

% Problem:02(a)- Find a best-fit equation to the data trend for parabolic (2nd order)

% Input the variables

x = 0:4:20; % x = Days
y = [67 84 98 125 149 185]; % y = Amount(x106)

% the parabolic equation is: a(x^2) + bx + c = 0. To find the best fit of this equation, let's distribute it in a PA = Q where we have to find out the matrix of A.

P = [length(x) sum(x)    sum(x.^2);
     sum(x)    sum(x.^2) sum(x.^3);
     sum(x.^2) sum(x.^3) sum(x.^4)];
Q = [sum(y) sum(x.*y) sum((x.^2).*y)]';

% Let's find the matrix A

A = P\Q; % A = [Ao A1 A2]

fprintf('The best fit parabolic equation is: %.4f * (x^2) + %.4f * x + %.4f = 0\n', A(3), A(2), A(1));

%putting a function so that we can measure every point precisely for finding a parabola equation

Y_func= @(xf) A(3).*(xf).^2 + A(2).*xf + A(1);

xr = 0 : 0.01 : 20;
yr = Y_func(xr);

% best fit parabola equation figure

figure(1);
plot(xr, yr, 'r');
xlabel('Days');
ylabel('Amount of bacteria');
grid on;
hold on;

% In this figure, we can see a figure which is a parabola. From this prove, we can reach out to a conclusion that we are successful to find the best fit parabola equation which is a(x^2) + bx + c = 0

% I know this is a best fit equation but not an exact equation of the providing variables. So, there must be an error. Let's find the error

Y = Y_func(x);
S = sum((Y-y).^2);

fprintf('Error = %.4f\n', S);

% (b) predict the number of bacteria after 40 days for the fitted equations

day = 40; 
bacteria_numbers = Y_func(day);

fprintf('the number of bacteria after 40 days for the fitted equation is: %d', bacteria_numbers);


