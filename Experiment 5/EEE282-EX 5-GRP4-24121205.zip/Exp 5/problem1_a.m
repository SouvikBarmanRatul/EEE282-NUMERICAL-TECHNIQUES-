clear all;
close all;
clc;
x = [26.67 93.33 148.69 315.56];  %x = Temperature in Degree Celcius
y = [1.35 0.085 0.012 0.00075];   %y = Viscosity in (N.s/m^2)

%Question(a): Plot the data-points in MATLAB and decide whether a straight line could fit them.

%Plotting the points

figure(1)
plot(x,y, 'ro', 'linewidth', 2);

%Displaying the name of the axises

xlabel('Temperature');
ylabel('Viscosity');
grid on;
hold on;
