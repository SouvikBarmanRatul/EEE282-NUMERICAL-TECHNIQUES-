clear all;
close all;
clc;
t = 0./1000:0.001:80./1000;    %vector t with values from 0 to 80ms and 0.001 interval of time.
S1 = 10.* sin(2.*pi.*15.*t);   %Defining sine wave with frequency 15 and amplitude 10.
S2 = 2.* sin(2.*pi.*30.*t);    %Defining sin wave with frequency 30 and amplitude 2.
C1 = 5.* cos(2.*pi.*60.*t);    %Defining cos wave with frequency 60 and amplitude 5.

figure (1)                     %it is used to get figures in different windows.
plot (t,S1,'b');               %plot is used to make a sine wave(S1) vs time graph,b indicates blue color.
xlabel('Times(ms)');
ylabel('Amplitude');
grid on;                       %to get grid lines on the graph.

figure (2)                     %it is used to get figures in different windows.
plot (t,S2,'r');               %plot is used to make a sine wave(S2) vs time graph,r indicates red color.
xlabel('Times(ms)');
ylabel('Amplitude');
grid on;                       %to get grid lines on the graph.

figure(3)                      %it is used to get figures in different windows.
plot(t,S1,'b');                %plot is used to make a sine wave(S1) vs time graph,b indicates blue color.
xlabel('Times(ms)');
ylabel('Amplitude');
grid on;                       %to get grid lines on the graph.
hold on;                       % to save the previous graph result.
plot (t,S2,'r');               %plot is used to make a sine wave(S2) vs time graph,r indicates red color.
xlabel('Times(ms)');
ylabel('Amplitude');
grid on;                        %to get grid lines on the graph.
hold on;                        % to save the previous graph result.

figure (4)                      %it is used to get figures in different windows.
subplot(2,2,1);                 % same window,to get the graph in first column first row.
plot (t,S1,'b');              %plot is used to make a sine wave(S1) vs time graph,b indicates blue color.
xlabel('Times(ms)');
ylabel('Amplitude');
title('Sin wave(S1) with f=15 & A=10');  %used to write the title of graph.
grid on;                                 %to get grid lines on the graph.
hold on;                             % to save the previous graph result.

subplot(2,2,2);                    % same window,to get the graph in second column first row.
plot (t,S2,'r');                 %plot is used to make a sine wave(S2) vs time graph,r indicates red color.
xlabel('Times(ms)');
ylabel('Amplitude');
title('Sin wave(S2)with f=30 & A=2');
grid on;                           %to get grid lines on the graph.
hold on;                        % to save the previous graph result.


figure(5)                    %it is used to get figures in different windows.
subplot(2,1,1);              % same window,to get the graph in first column first row.
plot(t,S1,'b');             %plot is used to make a sine wave(S1) vs time graph,b indicates blue color.
xlabel('Times(ms)');
ylabel('Amplitude');
grid on;                   %to get grid lines on the graph.
hold on;                % to save the previous graph result.
plot(t,S2,'r');        %plot is used to make a sine wave(S2) vs time graph,r indicates red color.
xlabel('Times(ms)');
ylabel('Amplitude');
grid on;                 %to get grid lines on the graph.
hold on;               % to save the previous graph result.
title('Sin wave with f=15,30 & A=10,2');%used to write the title of graph.
subplot(2,1,2);       % same window,to get the graph in first column first row.
plot(t,C1);         %plot is used to make cos wave(C1) vs Time(ms).
xlabel('Times(ms)');
ylabel('Amplitude');
grid on;            %to get grid lines on the graph.
title('Cos wave with f=60 & A=5');%used to write the title of graph.
