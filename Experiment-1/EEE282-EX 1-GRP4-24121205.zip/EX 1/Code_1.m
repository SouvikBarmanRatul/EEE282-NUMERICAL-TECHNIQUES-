clear all;
close all;
clc;
ID = [2 4 1 2 1 2 0 5];
A = [1:8];

element_mult = ID.*A ;  

H = A.' ;   % transpose of step 2

norm_mult = ID*H;   

final_value = element_mult.*norm_mult;  

root_fv = sqrt(final_value);

sz= size(element_mult);  

P = root_fv.^ 5;  % Last element of ID is 5

T = sz(2);    % 2nd size element

vector_sum = P + T;

Mean = mean(vector_sum);

fprintf('\nID = '); fprintf('%g ', ID); fprintf('\n');                     
fprintf('\nA = '); fprintf('%g ', A); fprintf('\n');                       
fprintf('\nElement-wise Multiplication (element_mult) = '); fprintf('%g ', element_mult); fprintf('\n');  
fprintf('\nTranspose of A (H) = '); fprintf('%g ', H); fprintf('\n');      
fprintf('\nNormal Multiplication (norm_mult) = %g\n', norm_mult);          
fprintf('\nFinal Value (final_value) = '); fprintf('%g ', final_value); fprintf('\n');  
fprintf('\nSquare Root of Final Value (root_fv) = '); fprintf('%.4f ', root_fv); fprintf('\n');  
fprintf('\nSize of element_mult (sz) = '); fprintf('%g ', sz); fprintf('\n'); 
fprintf('\nPower Value (P) = '); fprintf('%.4e ', P); fprintf('\n');       
fprintf('\nVector Sum = '); fprintf('%.4e ', vector_sum); fprintf('\n');   
fprintf('\nMean of Vector Sum = %.4f\n', Mean);                            












