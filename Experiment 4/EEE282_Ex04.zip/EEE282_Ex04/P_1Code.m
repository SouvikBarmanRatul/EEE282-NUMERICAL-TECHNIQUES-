clear all;
close all;
clc;

f = @(x)exp(x); %function call
xl = 2.1; %lower limit
xh = 6.7; %higher limit

n = 12; % total boxes that fits for all rules
h = (xh-xl)./n; % difference between one point to another point

x = xl:h:xh; %increment
y = f(x); %showing the array of y for the increment x's

%Question No.1- For Trapizoide Rule

a = (h./2).*(y(1)+y(end)+2.*sum(y(2:end-1))); %Trapizoide Rule Formula 

F = integral(f, xl, xh); %analytical value
error = ((a-F)/F).*100; %tolerance between the analytical and numberical value

fprintf('\nThe analytical value of this function is %.4f', F)
fprintf('\n\n\nFor Trapizoide Rule')
fprintf('\nThe area of this integer by using Trapizoide rule is %.4f', a)
fprintf('\nThe error of this analytical and numerical value in this rule is (in percentage)%.4f', error)

%Question No.1- For Simpson 1/3rd Rule

b = (h./3).*(y(1)+y(end)+4.*sum(y(2:2:end-1))+2.*sum(y(3:2:end-2))); %Simpson 1/3rd rule formula
error_1 = ((b-F)/F).*100; %tolerance between the analytical and numerical value

fprintf('\n\n\nFor Simpson 1/3rd Rule')
fprintf('\nThe area of this integer by using Simpson 1/3rd rule is %.4f', b)
fprintf('\nThe error of this analytical and numerical value in this rule is (in percentage)%.4f', error_1)

%Question No.1-For Simpson 3/8 Rule

c = 0;
for i = 2:n
    if rem(i-1,3)==0
        c = c + 2.*y(i);
    else
        c = c + 3.*y(i);
    end
end

c = (c + y(1)+y(end)).*(3.*h/8); %Simpson 3/8 rule formula
error_2 = ((c-F)/F).*100; %tolerance between the analytical and numerical value

fprintf('\n\n\nFor Simpson 3/8 Rule')
fprintf('\nThe area of this integer by using Simpson 3/8 rule is %.4f', c)
fprintf('\nThe error of this analytical and numerical value in this rule is (in percentage)%.4f', error_2)

