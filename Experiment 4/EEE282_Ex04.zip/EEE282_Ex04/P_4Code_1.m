clear all;
close all;
clc;

t = [0 1 2 3 4 5 6];  %% time (sec)
v = [0 2.15 3.26 4.18 4.82 5.61 4.77];  %% velocity (m/s)

xi = t(1);          %% lower limit
xf = t(end);        %% upper limit
n  = 6; %% number of intervals
h  = (xf - xi) / n; %% step size


a = (h/3) * (v(1)+ v(end)+ 4*sum(v(2:2:end-1))+ 2*sum(v(3:2:end-2)));

fprintf("Displacement =%f m\n", a);