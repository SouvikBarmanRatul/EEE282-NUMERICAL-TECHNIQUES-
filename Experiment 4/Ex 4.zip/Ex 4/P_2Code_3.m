clear all;
close all;
clc;

f = @(x) (1 + 5*sin(x.^2)) ./ (x + 1).^3/2;

xi = 0.5;   % lower limit
xf = 2;     % upper limit


F = integral(f, xi, xf)

n = 9;              % Size (must be multiple of 3 for Simpson 3/8)
h = (xf - xi) / n;

x = xi:h:xf; 
y = f(x);

a = 0;
for i = 2:n
    if rem(i-1,3) == 0      
        a = a + 2*y(i);
    else                   
        a = a + 3*y(i);
    end
end

a = (a + y(1) + y(end)) * 3*h/8    % Simpson 3/8 Approx Value

Error = (F - a)/F * 100            