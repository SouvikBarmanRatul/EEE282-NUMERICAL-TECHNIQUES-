clear all;
close all;
clc;


f = @(x) (1 + 5*sin(x.^2)) ./ (x + 1).^3/2;   
xi = 0.5;   % lower limit
xf = 2;     % upper limit


F = integral(f, xi, xf)   % Exact value

n = 8;        % Size (must be even for Simpson 1/3)
h = (xf - xi)/n;

x = xi:h:xf;          % increment  
y = f(x);

a = h/3 * ( y(1) + y(end) + 4*sum(y(2:2:end-1)) + 2*sum(y(3:2:end-2)) )   % integral value

Error = (F - a)/F * 100     
