clear all;
close all;
clc;

f=@(x)exp(x);%% Equation

xi=2.1; %% upper limit
xf=6.7; %% lower limit

F=exp(6.7)-exp(2.1) %%Exact value
n=8; %%Size
h=(xf-xi)/n;

x=xi:h:xf; %%increment  
y=f(x);

a=h/3*(y(1)+y(end)+4*sum(y(2:2:end-1))+2*sum(y(3:2:end-2))) %% integral value

Error=((F-a)/F)*100