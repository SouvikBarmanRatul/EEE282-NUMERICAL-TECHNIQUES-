clear all;
close all;
clc;

f=@(x)exp(x);%% Equation

xi=2.1; %% upper limit
xf=6.7; %% lower limit

F = exp(6.7)-exp(2.1) %%Exact value
n=9; %%Size
h=(xf-xi)/n;

x=xi:h:xf; %%increment  
y=f(x);

a=0;
for i=2:n
    if rem(i-1,3)==0
        a=a+2*y(i);
    else
       a=a+3*y(i);
    end
end

a=(a + y(1) + y(end))*3*h/8

Error=(F-a/F)*100












        