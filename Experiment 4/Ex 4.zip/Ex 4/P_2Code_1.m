clear all;
close all;
clc;

f = @(x) (1 + 5*sin(x.^2)) ./ (x + 1).^3/2;

xi = 0.5; %% lower limit
xf = 2;   %%upper limit
F = integral(f, xi, xf) %%Exact value
n = 9; 
h = (xf - xi)/n;

x = xi:h:xf;
y = f(x);

a = 0.5*h*( y(1) + y(end) + 2*sum(y(2:end-1)) )% Trapezoidal Rule

Error=(F-a/F)*100
