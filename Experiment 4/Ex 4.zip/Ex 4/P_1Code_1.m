clear all;
close all;
clc;

f=@(x)exp(x);%% Equation

xi=2.1; %% upper limit
xf=6.7; %% lower limit

F=exp(6.7)-exp(2.1) %%Exact value
n=9; %%Size
h=(xf-xi)/n;

x=xi:h:xf; %%increment  
y=f(x);

a=0.5*h*(y(1)+y(end)+2*sum(y(2:end-1))) %% integral value

Error=((F-a)/F)*100
