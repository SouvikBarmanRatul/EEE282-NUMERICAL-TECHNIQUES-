clear all;
close all;
clc;

f = @(x) (x.^5 + x + 1);

%%Bisection Method

%interval
xlow= -1;
xhigh=0;

e = 100;
tol=1e-4;

%variable for iteration  
xr_prev=0;
iter=0;

if (f(xlow)*f(xhigh))>0
    disp(' No root in the interval');
else
    while(e>tol)
        iter=iter+1;
        
        xr= (xhigh+xlow)/2;  % Midpoint
        
        % update interval base on sign
        if (f(xr)*f(xlow))<0
            xhigh=xr;
        else
           xlow=xr;
        end
        
        %Compute approximate error
        e= abs((xr-xr_prev)/xr)*100;
        xr_prev=xr;
        
    end
end

%final results
iter
xr
e
        
           
        
        
        



