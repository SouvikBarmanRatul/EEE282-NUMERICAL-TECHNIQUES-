clear all;
close all;
clc;

f = @(x) (exp(-x) - 1);
%%%Newton_Raphson Method

h   = 1e-6;
xr  = 0;
tol = 1e-8;
e   = 100;

% Iteration variables
iter = 0;


while (e > tol)
    iter = iter + 1;
    xr_prev = xr;  % Store previous value

    %Approximate derivative by using FDD
    derivative = (f(xr_prev + h) - f(xr_prev)) / h;
    
    %Newton_Raphson update
    xr = xr_prev - f(xr_prev) / derivative;
    
   
   e = abs(xr - xr_prev);   % absolute error
   
  
  end
 
   % Final results
   iter
   xr
   e
   
   